import express from "express";
import bodyparser from "body-parser";
import axios from "axios";

const app=express();
app.use(express.static("public"));
app.use(bodyparser.urlencoded({extended:true}));

app.get("/joke",async(req,res)=>{
    try {
    const result = await axios.get("https://v2.jokeapi.dev/joke/Any");

    let joke;
    if (result.data.type === "single") {
      // One-liner joke
      joke = {
        title: "Here's a Joke!",
        content: result.data.joke
      };
    } else {
      // Two-part joke
      joke = {
        title: result.data.setup,
        content: result.data.delivery
      };
    }

    res.render("index.ejs", { joke: joke });
  } catch (error) {
    res.render("index.ejs", {
      joke: {
        title: "Error 😢",
        content: "Could not fetch joke. Try again later."
      }
    });
  }
});
app.get("/",async(req,res)=>{
    try {
    const result = await axios.get("https://v2.jokeapi.dev/joke/Any");

    let joke;
    if (result.data.type === "single") {
      // One-liner joke
      joke = {
        title: "Here's a Joke!",
        content: result.data.joke
      };
    } else {
      // Two-part joke
      joke = {
        title: result.data.setup,
        content: result.data.delivery
      };
    }

    res.render("index.ejs", { joke: joke });
  } catch (error) {
    res.render("index.ejs", {
      joke: {
        title: "Error 😢",
        content: "Could not fetch joke. Try again later."
      }
    });
  }
});

app.listen(3000,()=>{
    console.log("server is running on port 3000");
})