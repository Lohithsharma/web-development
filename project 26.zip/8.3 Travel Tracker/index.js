import express from "express";
import bodyParser from "body-parser";
import pg from "pg";

const db=new pg.Client({
  user:"postgres",
  host:"localhost",
  database:"world",
  password:"21062006",
  port:5432
});
db.connect();



const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

async function checkvisited(){
  const result=await db.query("select country_code from visited_countries");
  let countries=[];
  result.rows.forEach((country)=>{
    countries.push(country.country_code);
  });
  return countries;
}

app.get("/",async(req,res)=>{
  const countries=await checkvisited();
  res.render("index.ejs", { countries: countries, total: countries.length });
});

app.post("/add",async(req,res)=>{
  const countries=await checkvisited();
  const input=req.body["country"];
  const result=await db.query("select country_code from countries where country_name=($1)",[input]);

  if (result.rows.length !== 0) {
    const data=result.rows[0].country_code;
    try{
      const t = await db.query(
    "SELECT * FROM visited_countries WHERE country_code = $1",
    [data]
  );

  if (t.rows.length > 0) {
    return res.render("index.ejs",{total:countries.length,countries:countries,error:"country has already been added,try again!"});
  } else {
    await db.query("insert into visited_countries(country_code) values($1)",[data,]);
    res.redirect("/");
  }
    }catch(error){
      res.render("index.ejs",{error:error});
    } 
  }
  else{
      res.render("index.ejs", res.render("index.ejs", {total: countries.length,countries: countries,error: "Error loading data"
    }) );
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
