import express from "express";
import axios from "axios";
import pg from "pg";
import path from "path";
import { fileURLToPath } from "url";

const app = express();

// Setup for __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

// View engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// PostgreSQL connection
const db = new pg.Client({
  user: "postgres",
  host: "localhost",
  database: "booknotes",
  password: "21062006",
  port: 5432,
});
db.connect();

// Homepage - show all books
app.get("/", async (req, res) => {
  try {
    const result = await db.query("SELECT * FROM books ORDER BY date_read DESC");
    res.render("index", { books: result.rows });
  } catch (err) {
    console.error("Error loading books:", err.message);
    res.send("Failed to load books.");
  }
});

app.get("/add", (req, res) => {
  res.render("add.ejs");
});


// Show Edit Page for a Book
app.get("/edit/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const result = await db.query("SELECT * FROM books WHERE id = $1", [id]);
    res.render("edit", { book: result.rows[0] });
  } catch (err) {
    console.error("Error loading edit form:", err.message);
    res.send("Failed to load book for editing.");
  }
});

// Add New Book
app.post("/add", async (req, res) => {
  try {
    const { title, author, rating, review } = req.body;
    const date_read = new Date();
    const cover_url = `https://covers.openlibrary.org/b/title/${encodeURIComponent(title)}-L.jpg`;

    await db.query(
      "INSERT INTO books (title, author, cover_url, rating, review, date_read) VALUES ($1, $2, $3, $4, $5, $6)",
      [title, author, cover_url, rating, review, date_read]
    );

    res.redirect("/");
  } catch (error) {
    console.error("Error adding book:", error.message);
    res.send("Failed to add book.");
  }
});

// Edit Book
app.post("/edit/:id", async (req, res) => {
  const { id } = req.params;
  const { title, author, rating, review } = req.body;
  const cover_url = `https://covers.openlibrary.org/b/title/${encodeURIComponent(title)}-L.jpg`;

  try {
    await db.query(
      `UPDATE books
       SET title = $1, author = $2, rating = $3, review = $4, cover_url = $5
       WHERE id = $6`,
      [title, author, rating, review, cover_url, id]
    );
    res.redirect("/");
  } catch (err) {
    console.error("Error updating book:", err.message);
    res.send("Failed to update book.");
  }
});

app.post("/delete/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await db.query("DELETE FROM books WHERE id = $1", [id]);
    res.redirect("/");
  } catch (err) {
    console.error("Error deleting book:", err.message);
    res.status(500).send("Failed to delete the book.");
  }
});


// Start server
app.listen(3000, () => {
  console.log("Server is running on http://localhost:3000");
});
