var rn1=Math.floor(Math.random()*6)+1;
var diceWroll="./images/dice"+rn1+".png";
var randomNumber=document.querySelectorAll("img")[0];
randomNumber.setAttribute("src",diceWroll);
var rn2=Math.floor(Math.random()*6)+1;
var hell="./images/dice"+rn2+".png";
var random=document.querySelectorAll("img")[1];
random.setAttribute("src",hell);
if(rn1===rn2){
    document.querySelector("h1").innerHTML="___DRAW___";
}
if(rn1>rn2){
    document.querySelector("h1").innerHTML="Player 1 won....";
}
if(rn2>rn1){
    document.querySelector("h1").innerHTML="Player 2 won ...."; 
}