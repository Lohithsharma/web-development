import express from "express";
import axios from "axios";

const app = express();
const port = 3000;
const API_URL = "https://secrets-api.appbrewery.com/";

//TODO 1: Fill in your values for the 3 types of auth.
const yourUsername = "jacksparrow";
const yourPassword = "ilovewebdev";
const yourAPIKey = "b1303fa0-a01a-40af-a5fb-fe6db56f43c5";
const yourBearerToken = "aa87d9af-f92d-447e-93f6-8545de02d063";

app.get("/", (req, res) => {
  res.render("index.ejs",{content:"API Response"});
});

app.get("/noAuth", async(req, res) => {
  try{
    const response=await axios.get("https://secrets-api.appbrewery.com/random");
    const result=response.data
    res.render("index.ejs", { content:JSON.stringify(result)});
  }catch(error){
    res.status(404).send(error.message);
    }
});
  //TODO 2: Use axios to hit up the /random endpoint
  //The data you get back should be sent to the ejs file as "content"
  //Hint: make sure you use JSON.stringify to turn the JS object from axios into a string.


app.get("/basicAuth", async(req, res) => {
  try{
    const response=await axios.get("https://secrets-api.appbrewery.com/all?page=2",{
      auth:{
        username:yourUsername,
        password:yourPassword,
      },
    });
    const result=response.data;
    res.render("index.ejs", { content:JSON.stringify(result)});
  }catch(error){
       res.status(404).send(error.message); 
  }
  //TODO 3: Write your code here to hit up the /all endpoint
  //Specify that you only want the secrets from page 2
  //HINT: This is how you can use axios to do basic auth:
  // https://stackoverflow.com/a/74632908
  /*
   axios.get(URL, {
      auth: {
        username: "abc",
        password: "123",
      },
    });
  */
});

app.get("/apiKey", async (req, res) => {
  try {
    const response = await axios.get("https://secrets-api.appbrewery.com/filter", {
      params: {
        score: 5,
        apiKey: yourAPIKey, // make sure this is correct
      },
    });
    res.render("index.ejs", { content: JSON.stringify(response.data) });
  } catch (error) {
    console.error("API Key Error:", error.response?.data || error.message);
    res
      .status(error.response?.status || 500)
      .send(error.response?.data?.error || error.message);
  }
});


app.get("/bearerToken", async(req, res) => {
  try{
    const response=await axios.get("https://secrets-api.appbrewery.com/secrets/42",{
      headers:{
        Authorization:`Bearer ${yourBearerToken}`
      },
    });
    const result=response.data;
    res.render("index.ejs", { content:JSON.stringify(result) });
  }catch(error){
        res.status(404).send(error.message);
  }
  //TODO 5: Write your code here to hit up the /secrets/{id} endpoint
  //and get the secret with id of 42
  //HINT: This is how you can use axios to do bearer token auth:
  // https://stackoverflow.com/a/52645402
  /*
  axios.get(URL, {
    headers: { 
      Authorization: `Bearer <YOUR TOKEN HERE>` 
    },
  });
  */
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
